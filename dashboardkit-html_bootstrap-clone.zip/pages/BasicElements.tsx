
import React from 'react';

const BasicElements: React.FC = () => {
  return (
    <div className="container-fluid">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h4 className="fw-bold mb-0">Basic Elements</h4>
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb mb-0">
            <li className="breadcrumb-item"><a href="#" className="text-decoration-none text-primary">Dashboard</a></li>
            <li className="breadcrumb-item active">Basic Elements</li>
          </ol>
        </nav>
      </div>

      <div className="row">
        <div className="col-lg-6">
          <div className="card">
            <div className="card-header bg-transparent py-3">
              <h6 className="card-title mb-0 fw-bold">Buttons</h6>
            </div>
            <div className="card-body">
              <p className="text-muted small mb-3">Default buttons with different states.</p>
              <div className="d-flex flex-wrap gap-2">
                <button className="btn btn-primary">Primary</button>
                <button className="btn btn-secondary">Secondary</button>
                <button className="btn btn-success">Success</button>
                <button className="btn btn-danger">Danger</button>
                <button className="btn btn-warning">Warning</button>
                <button className="btn btn-info text-white">Info</button>
              </div>
              <hr className="my-4 opacity-10" />
              <p className="text-muted small mb-3">Outline buttons.</p>
              <div className="d-flex flex-wrap gap-2">
                <button className="btn btn-outline-primary">Primary</button>
                <button className="btn btn-outline-success">Success</button>
                <button className="btn btn-outline-danger">Danger</button>
              </div>
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="card">
            <div className="card-header bg-transparent py-3">
              <h6 className="card-title mb-0 fw-bold">Badges</h6>
            </div>
            <div className="card-body">
              <p className="text-muted small mb-3">Default and Pill badges.</p>
              <div className="d-flex flex-wrap gap-2 mb-4">
                <span className="badge bg-primary">Primary</span>
                <span className="badge bg-success">Success</span>
                <span className="badge bg-danger">Danger</span>
                <span className="badge bg-warning text-dark">Warning</span>
              </div>
              <div className="d-flex flex-wrap gap-2">
                <span className="badge rounded-pill bg-primary">Primary</span>
                <span className="badge rounded-pill bg-success">Success</span>
                <span className="badge rounded-pill bg-info text-white">Info</span>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 mt-4">
          <div className="card">
            <div className="card-header bg-transparent py-3">
              <h6 className="card-title mb-0 fw-bold">Alerts</h6>
            </div>
            <div className="card-body">
              <div className="row g-3">
                <div className="col-md-6">
                  <div className="alert alert-primary mb-0" role="alert">
                    A simple primary alert—check it out!
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="alert alert-success mb-0" role="alert">
                    A simple success alert—check it out!
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="alert alert-warning mb-0" role="alert">
                    A simple warning alert—check it out!
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="alert alert-danger mb-0" role="alert">
                    A simple danger alert—check it out!
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BasicElements;
