
// Vanilla JS mantiqi - React-siz Dashboard navigatsiyasini boshqarish uchun

/**
 * Sidebar-ni yoqish/o'chirish (mobil qurilmalar uchun)
 */
(window as any).toggleSidebar = () => {
  const sidebar = document.getElementById('sidebar');
  if (sidebar) {
    sidebar.classList.toggle('show');
  }
};

/**
 * Bo'limlarni ko'rsatish/yashirish
 * @param sectionId Ko'rsatilishi kerak bo'lgan bo'lim ID-si
 * @param element Bosilgan menyu elementi
 */
(window as any).showSection = (sectionId: string, element: HTMLElement) => {
  // Barcha bo'limlarni yashirish
  const sections = document.querySelectorAll('.section-content');
  sections.forEach(section => {
    section.classList.remove('active');
  });

  // Tanlangan bo'limni ko'rsatish
  const targetSection = document.getElementById(sectionId);
  if (targetSection) {
    targetSection.classList.add('active');
  }

  // Menyu elementlaridan active klassini tozalash
  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(item => {
    item.classList.remove('active');
  });

  // Tanlangan menyu elementiga active klassini qo'shish
  element.classList.add('active');

  // Mobil qurilmada bo'lim tanlanganda sidebar-ni yopish
  const sidebar = document.getElementById('sidebar');
  if (sidebar && window.innerWidth < 992) {
    sidebar.classList.remove('show');
  }
};

console.log("Dashboard mantiqi yuklandi (Vanilla JS)");
