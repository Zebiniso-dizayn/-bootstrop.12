
import React from 'react';
import { MoreVertical, Edit2, Trash2, Eye } from 'lucide-react';
import { TableUser } from '../types';

const users: TableUser[] = [
  { id: 1, name: "Alice Freeman", email: "alice@example.com", status: "Active", role: "Manager", avatar: "https://picsum.photos/id/1/100/100" },
  { id: 2, name: "Bob Wilson", email: "bob@example.com", status: "Inactive", role: "Developer", avatar: "https://picsum.photos/id/2/100/100" },
  { id: 3, name: "Charlie Davis", email: "charlie@example.com", status: "Active", role: "Designer", avatar: "https://picsum.photos/id/3/100/100" },
  { id: 4, name: "Diana Prince", email: "diana@example.com", status: "Pending", role: "CEO", avatar: "https://picsum.photos/id/4/100/100" },
  { id: 5, name: "Edward Norton", email: "edward@example.com", status: "Active", role: "DevOps", avatar: "https://picsum.photos/id/5/100/100" },
  { id: 6, name: "Fiona Apple", email: "fiona@example.com", status: "Inactive", role: "HR", avatar: "https://picsum.photos/id/6/100/100" },
];

const BootstrapTable: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Bootstrap Data Table</h1>
        <nav className="text-sm text-gray-500">
          <span className="hover:text-blue-600 cursor-pointer">Tables</span>
          <span className="mx-2">/</span>
          <span className="text-gray-400">Bootstrap Table</span>
        </nav>
      </div>

      <section className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold">User Management</h2>
            <p className="text-sm text-gray-500">Overview of all registered users in the platform.</p>
          </div>
          <button className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition flex items-center gap-2">
            <span>+ Add New User</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider font-semibold">
              <tr>
                <th className="px-6 py-4 border-b border-gray-100">User</th>
                <th className="px-6 py-4 border-b border-gray-100">Role</th>
                <th className="px-6 py-4 border-b border-gray-100">Status</th>
                <th className="px-6 py-4 border-b border-gray-100 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full border border-gray-200" />
                      <div>
                        <p className="text-sm font-semibold text-gray-800">{user.name}</p>
                        <p className="text-xs text-gray-500">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {user.role}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-[10px] font-bold uppercase rounded ${
                      user.status === 'Active' ? 'bg-green-100 text-green-700' :
                      user.status === 'Inactive' ? 'bg-red-100 text-red-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center gap-2">
                      <button className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-all">
                        <Eye size={16} />
                      </button>
                      <button className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded transition-all">
                        <Edit2 size={16} />
                      </button>
                      <button className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-all">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-4 border-t border-gray-100 bg-gray-50 flex items-center justify-between text-sm text-gray-500">
          <p>Showing 1 to {users.length} of {users.length} entries</p>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1 border border-gray-200 rounded hover:bg-white disabled:opacity-50">Prev</button>
            <button className="px-3 py-1 bg-blue-600 text-white rounded">1</button>
            <button className="px-3 py-1 border border-gray-200 rounded hover:bg-white disabled:opacity-50">Next</button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default BootstrapTable;
