// Fix: Added React import to resolve "Cannot find namespace 'React'" error when referencing React.ReactNode
import React from 'react';

export type NavItem = {
  label: string;
  path: string;
  icon?: React.ReactNode;
};

export type NavGroup = {
  title: string;
  items: NavItem[];
};

export interface TableUser {
  id: number;
  name: string;
  email: string;
  status: 'Active' | 'Inactive' | 'Pending';
  role: string;
  avatar: string;
}